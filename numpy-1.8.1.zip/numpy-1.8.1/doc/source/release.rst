*************
Release Notes
*************

.. include:: ../release/1.8.1-notes.rst
.. include:: ../release/1.8.0-notes.rst
.. include:: ../release/1.7.2-notes.rst
.. include:: ../release/1.7.1-notes.rst
.. include:: ../release/1.7.0-notes.rst
.. include:: ../release/1.6.2-notes.rst
.. include:: ../release/1.6.1-notes.rst
.. include:: ../release/1.6.0-notes.rst
.. include:: ../release/1.5.0-notes.rst
.. include:: ../release/1.4.0-notes.rst
.. include:: ../release/1.3.0-notes.rst
