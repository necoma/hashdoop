
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.8.1'
version = '1.8.1'
full_version = '1.8.1'
git_revision = '62a7575fd82ddf028517780c01fecf7e0cca27aa'
release = True

if not release:
    version = full_version
